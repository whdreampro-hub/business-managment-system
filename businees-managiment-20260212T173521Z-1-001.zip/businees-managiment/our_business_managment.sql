-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 26, 2026 at 05:53 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `our_business_managment`
--

-- --------------------------------------------------------

--
-- Table structure for table `abakozi`
--

CREATE TABLE `abakozi` (
  `id` int(11) NOT NULL,
  `employee_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `work_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `abakozi`
--

INSERT INTO `abakozi` (`id`, `employee_name`, `description`, `amount`, `work_date`) VALUES
(1, 'gasega', 'kuvoma', 100, '2026-01-26');

-- --------------------------------------------------------

--
-- Table structure for table `credits`
--

CREATE TABLE `credits` (
  `id` int(11) NOT NULL,
  `credit_text` text NOT NULL,
  `status` enum('paid','not_paid') DEFAULT 'not_paid',
  `created_at` datetime DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `day`
--

CREATE TABLE `day` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `amount` int(11) NOT NULL,
  `day_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `others`
--

CREATE TABLE `others` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `amount` int(11) NOT NULL,
  `other_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `saving`
--

CREATE TABLE `saving` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `amount` int(11) NOT NULL,
  `save_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saving`
--

INSERT INTO `saving` (`id`, `description`, `amount`, `save_date`) VALUES
(2, 'kwa sombe', 18, '2026-01-26');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `email`, `username`, `password`) VALUES
(1, 'emmanuel@gmai.com', 'emmy', '$2y$10$/4sQ3nHW22pa0u9Ps92BJu.EI23IczssKoJ9d4Jq.o13bclmSG9Au'),
(2, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$Ptt/QaDpuVOIYVU5Vb5EOOJuOiBljXvtXnf6FbkOlEF8ujTEcpKaO'),
(3, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$5Gg7kG4i8feBKdZ4hH99A.U4Ly2HkVP/tY5lLRz7kS7pykK120ZTK'),
(4, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$9TKR5s4Kauz58eXumTKUn.Cd8A7g885XEkp4Rq/88Nt.NTe21tnsS'),
(5, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$yO.A.GTkMXS435vRLstd0OFWgaNOeSVpSl1679pNULIu3LlDw24Iq'),
(6, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$FaNZ1tR8R6t.3Y7P0wVqR.hBYruNzOiXdvhcoWUNcresGXCFGfFbm'),
(7, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$x43oUAj3go38B9anbHqtLud/9zI8hAs5bbM1P/QVAY6Pf4SSAx.j2'),
(8, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$bCYVGi0/oNiS7LhnaRxpSuP6GKrKnGS04uzfBKwZpG51IgJmbKsaO'),
(9, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$gP5l0V.Sx5PyjUeErapm7OpRn7ealjau7SS01oSddXUzsV4fwaG2S'),
(10, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$Z2YEFa3lbCwxVNtDC1DIrufG/.6gxcqQANjM8sUQ9jFA76XbVDSJ.'),
(11, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$R8wXxWo6XlE0JBFPVKbW9ebVhkeuRms5ZQYmK.n08Agt8AhB2mRWq'),
(12, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$uNcJX0JOTo5e0UaBlPPnceFgkSB7H7Bi43fg0NRugSyKhcPvUtoSe'),
(13, 'whdreampro@gmail.com', 'whdreampro', '$2y$10$2BJW.qtvSQq8Z5vPmHuCDeJMwPMAbvjSVbcmlHEvHzHtupvyvx1nC'),
(14, 'elisa@gmail.com', 'elisa', '$2y$10$goAQ2UgEsc2uvoiWqk1gAuhdm.88WyL/o2s9yzICubLq7MEeZX8su'),
(15, 'buzizi@gmail.com', 'buzizi', '$2y$10$Nq2zYo.m3b.yK7i1hU9ihu62F.HUJtU8UrQUZM0DWyHEWhcsLthJO'),
(16, 'hirwa@gmail.com', 'hirwa', '$2y$10$Ug1/oHHVlz7r/hs.vPEzMO5LGih/lrXAl.19iqkhPM3xa/z/Q4ii.');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `task_text` text NOT NULL,
  `status` enum('done','not_done') DEFAULT 'not_done',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`, `created_at`) VALUES
(6, 'emmanuel@gmail.com', 'emmanuel', '$2y$10$qKnY4.GwXUwMDinqizKkQeE4hai5wIaPkNuuoTD1tqxlu9qLPSz7m', '2026-01-25 07:00:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abakozi`
--
ALTER TABLE `abakozi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `credits`
--
ALTER TABLE `credits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `day`
--
ALTER TABLE `day`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `others`
--
ALTER TABLE `others`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saving`
--
ALTER TABLE `saving`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abakozi`
--
ALTER TABLE `abakozi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `credits`
--
ALTER TABLE `credits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `day`
--
ALTER TABLE `day`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `others`
--
ALTER TABLE `others`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `saving`
--
ALTER TABLE `saving`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
