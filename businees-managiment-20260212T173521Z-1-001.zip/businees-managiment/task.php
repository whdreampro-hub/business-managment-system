<?php
include "db.php";

/* INSERT NEW Task */
if(isset($_POST['save'])){
    $task_text = $_POST['task_text'];
    $sql = "INSERT INTO tasks (task_text) VALUES ('$task_text')";
    mysqli_query($conn, $sql);
    header("Location: task.php");
    exit();
}

/* DELETE Task */
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM tasks WHERE id=$id");
    header("Location: task.php");
    exit();
}

/* UPDATE STATUS */
if(isset($_GET['status']) && isset($_GET['id'])){
    $id = $_GET['id'];
    $status = $_GET['status'];
    mysqli_query($conn, "UPDATE tasks SET status='$status' WHERE id=$id");
    header("Location: task.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tasks We have</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{
            font-family:Arial;
             background:#f2f2f2;
              display:flex;
               justify-content:center;
            }

        .container{
            background:white;
             width:60%;
              margin-top:20px;
               padding:20px;
                border-radius:10px;
            }
        textarea{
            width:100%;
             height:80px;
              padding:10px;
            }
        button{padding:8px 15px;
         border:none;
          background:black;
           color:white;
            border-radius:5px;
             cursor:pointer;
            }
        .item{
            display:flex;
         justify-content:space-between;
          background:#eee;
           padding:10px;
            margin-top:10px;
             border-radius:5px;
              align-items:center;
            }
        .item p.paid{
            text-decoration:line-through;
             color:green;
            }
        /* MEDIA QUERY */
        @media(max-width:600px){
            .container{width:95%;}
            .item{flex-direction:column; gap:5px;}
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Our Task we have</h2>

    <!-- FORM -->
    <form method="POST">
        <textarea name="task_text" placeholder="Andika Tasks hano...." required></textarea><br><br>
        <button name="save">Save Task</button>
    </form>

    <hr>

    <!-- DISPLAY tasks -->
    <?php


session_start();

if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}




    $result = mysqli_query($conn, "SELECT * FROM tasks ORDER BY id DESC");
    while($row = mysqli_fetch_assoc($result)){
        $checked = $row['status']=='done' ? 'checked' : '';
        $class = $row['status']=='done' ? 'done' : '';
    ?>
    <div class="item">
        <div>
            <form method="GET" style="display:inline;">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <input type="hidden" name="status" value="<?php echo $row['status']=='done'?'not_done':'done'; ?>">
                <input type="checkbox" onchange="this.form.submit()" <?php echo $checked; ?>>
            </form>
            <p class="<?php echo $class; ?>"><?php echo $row['task_text']; ?></p>
            <small><?php echo $row['created_at']; ?></small>
        </div>
        <a href="task.php?delete=<?php echo $row['id']; ?>"><button style="background:red;">Delete</button></a>
    </div>
    <?php } ?>

    <!-- here link of back to dashboard-->
    <a href="dashboard.php"
     style="height:25px; 
        width:60px;
        border-radius:5px;
        background:blue;
        text-decoration:none;"
    >Bacrk</a>

</div>

</body>
</html>
