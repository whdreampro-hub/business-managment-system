<?php
include "db.php";


session_start();

if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}




// DELETE record
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM day WHERE id=$id");
}

// SAVE record
if(isset($_POST['save'])){
    $description = $_POST['description'];
    $amount = $_POST['amount'];
    $date = date("Y-m-d");

    mysqli_query($conn, "INSERT INTO day(description, amount, day_date)
                         VALUES('$description','$amount','$date')");
}

// Get all records ordered by date
$result = mysqli_query($conn, "SELECT * FROM day ORDER BY day_date DESC");

// Group total per date
$totalPerDay = mysqli_query($conn, 
    "SELECT day_date, SUM(amount) as total 
     FROM day GROUP BY day_date ORDER BY day_date DESC"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daily Business</title>
    <link rel="stylesheet" href="day.css">
</head>
<body>

<div class="container">
    <h2>Ibyajyiye ku munsi</h2>

    <form method="post">
        <textarea name="description" placeholder="Andika product..." required></textarea>
        <input type="number" name="amount" placeholder="Amafaranga"  required>
        <button type="submit" name="save">Save</button>
    </form>

<?php
// gushira hamwe 
while($dayRow = mysqli_fetch_assoc($totalPerDay)){
    $date = $dayRow['day_date'];
    $total = $dayRow['total'];

    echo "<h3>Tariki $date total: $total k</h3>";

    $items = mysqli_query($conn, "SELECT * FROM day WHERE day_date='$date'");
    echo "<table>";
    echo "<tr><th>Details</th><th>Amafaranga</th><th>Gusiba</th></tr>";

    while($row = mysqli_fetch_assoc($items)){
        echo "<tr>
                <td>{$row['description']}</td>
                <td>{$row['amount']}k </td>
                <td>
                  <a href='day.php?delete={$row['id']}' onclick='return confirm(\"Delete this record?\")'>Delete</a>
                </td>
              </tr>";
    }

    echo "</table><br>";
}
?>


    <!-- here link of back to dashboard-->
    <a href="dashboard.php"
     style="height:25px; 
        width:60px;
        border-radius:5px;
        background:blue;
        text-decoration:none;"
    >Bacrk</a>


</div>

</body>
</html>
