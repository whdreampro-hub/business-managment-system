


<?php
session_start();

if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Business</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
            <!--here is main division of all dashboard-->
    <div class="main">
        <label>Our Business Management</label>

        <!--here is logout also-->
        <form action="logout.php" method="post">
    <button type="submit">Logout</button>
</form><br><br>


        <div class="all-task">
            <div class="card">
                <a href="day.php">Today
                <img src="day.jpeg" alt="Today">
            </div>
        </a>
            <div class="card">
                <a href="task.php">Task
                <img src="task.jpeg" alt="Task">
            </div>
            </a>

            <div class="card">
                <a href="credit.php">Imyenda
                <img src="credit.jpeg" alt="Credit">
            </div>
            </a>
        </div>

        <div class="all-task">
            <div class="card">
                <a href="saving.php">Saving
                <img src="save.jpeg" alt="Saving">
            </div>
            </a>

            <div class="card">
                <a href="abakozi.php">Abakozi
                <img src="abakozi.jpeg" alt="Abakozi">
            </div>
            </a>

            <div class="card">
                <a href="others.php">Others
                <img src="other.jpeg" alt="Others">
            </div>
            </a>
        </div>

        <a href="update_user.php" style="height:25px; 
        width:60px;
        border-radius:5px;
        background:blue;
        text-decoration:none;
        ">HINDURA</a>

    </div>

</body>
</html>
