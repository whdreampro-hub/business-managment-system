<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
    

</head>
<body>

<h2>Hindura Amakuru yawe</h2>

<form action="update_use.php" method="post">
    <input type="email" name="email" placeholder="New Email" required><br><br>
    <input type="text" name="username" placeholder="New Username" required><br><br>
    <input type="password" name="password" placeholder="New Password" required><br><br>
    <button type="submit">Hindura</button>
</form>

<!-- here link of back to dashboard-->
    <a href="dashboard.php"
     style="height:25px; 
        width:60px;
        border-radius:5px;
        background:blue;
        text-decoration:none;"
    >Back</a>

</body>
</html>
