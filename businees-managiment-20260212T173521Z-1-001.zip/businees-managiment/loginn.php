<?php
session_start();
include "db.php";

if(isset($_POST['username']) && isset($_POST['password'])){

    $username = $_POST['username'];
    $password = $_POST['password'];

    // check user in database
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) == 1){

        $row = mysqli_fetch_assoc($result);

        // verify password
        if(password_verify($password, $row['password'])){

            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];

            // redirect to dashboard
            header("Location: dashboard.php");
            exit();

        } else {
            $message="your password is incorrect";
            echo"<script>alert('$message');
            window.location.href='login.php';   
            </script>";
            
        }

    } else {
        echo "User not found!";
        header("location: login.php");
    }

}else{
    echo "Please fill all fields!";
}
?>
