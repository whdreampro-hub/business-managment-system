<?php
include "db.php";
session_start();

// Protect page
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}

// DELETE record
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM abakozi WHERE id=$id");
}

// SAVE record
if(isset($_POST['save'])){
    $employee_name = $_POST['employee_name'];
    $description = $_POST['description'];
    $amount = $_POST['amount'];
    $date = date("Y-m-d");

    mysqli_query($conn, "INSERT INTO abakozi(employee_name, description, amount, work_date)
                         VALUES('$employee_name','$description','$amount','$date')");
}

// Group total per day
$totalPerDay = mysqli_query($conn,
    "SELECT work_date, SUM(amount) AS total 
     FROM abakozi GROUP BY work_date ORDER BY work_date DESC"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Abakozi Management</title>
    <link rel="stylesheet" href="abakozi.css">
</head>
<body>

<div class="container">
    <h2>Management y'Abakozi</h2>

    <form method="post">
        <input type="text" name="employee_name" placeholder="Izina ry'umukozi" required>
        <textarea name="description" placeholder="Icyo wayamuhereye (akazi)"></textarea>
        <input type="number" name="amount" placeholder="Amafaranga yahawe" required>
        <button type="submit" name="save">Save</button>
    </form>

<?php
while($dayRow = mysqli_fetch_assoc($totalPerDay)){
    $date = $dayRow['work_date'];
    $total = $dayRow['total'];

    echo "<h3>Tariki $date amafaranga yahawe abakozi: $total Frw</h3>";

    $items = mysqli_query($conn, "SELECT * FROM abakozi WHERE work_date='$date'");
    echo "<table>";
    echo "<tr><th>Izina</th><th>Impamvu</th><th>Amafaranga</th><th>Action</th></tr>";

    while($row = mysqli_fetch_assoc($items)){
        echo "<tr>
                <td>{$row['employee_name']}</td>
                <td>{$row['description']}</td>
                <td>{$row['amount']} Frw</td>
                <td>
                  <a href='abakozi.php?delete={$row['id']}' 
                     onclick='return confirm(\"Delete this record?\")'>Delete</a>
                </td>
              </tr>";
    }

    echo "</table><br>";
}
?>

</div>

<!-- here link of back to dashboard-->
    <a href="dashboard.php"
     style="height:25px; 
        width:60px;
        border-radius:5px;
        background:blue;
        text-decoration:none;"
    >Bacrk</a>

<a href="logout.php" class="logout">Logout</a>

</body>
</html>
