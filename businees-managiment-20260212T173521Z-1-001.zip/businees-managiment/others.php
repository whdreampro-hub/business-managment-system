<?php
include "db.php";
session_start();

// Protect page
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}

// DELETE record
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM others WHERE id=$id");
}

// SAVE record
if(isset($_POST['save'])){
    $description = $_POST['description'];
    $amount = $_POST['amount'];
    $date = date("Y-m-d");

    mysqli_query($conn, "INSERT INTO others(description, amount, other_date)
                         VALUES('$description','$amount','$date')");
}

// Group totals per day
$totalPerDay = mysqli_query($conn,
    "SELECT other_date, SUM(amount) AS total 
     FROM others GROUP BY other_date ORDER BY other_date DESC"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Others / Expenses</title>
    <link rel="stylesheet" href="others.css">
</head>
<body>

<div class="container">
    <h2>Others / Ibyakoreshejwe (Expenses)</h2>

    <form method="post">
        <textarea name="description" placeholder="Andika icyo wakoresheje..." required></textarea>
        <input type="number" name="amount" placeholder="Amafaranga yakoreshejwe" required>
        <button type="submit" name="save">Save</button>
    </form>

<?php
while($dayRow = mysqli_fetch_assoc($totalPerDay)){
    $date = $dayRow['other_date'];
    $total = $dayRow['total'];

    echo "<h3>Tariki $date wakoresheje: $total Frw</h3>";

    $items = mysqli_query($conn, "SELECT * FROM others WHERE other_date='$date'");
    echo "<table>";
    echo "<tr><th>Details</th><th>Amafaranga</th><th>Action</th></tr>";

    while($row = mysqli_fetch_assoc($items)){
        echo "<tr>
                <td>{$row['description']}</td>
                <td>{$row['amount']} Frw</td>
                <td>
                  <a href='others.php?delete={$row['id']}'
                     onclick='return confirm(\"Delete this record?\")'>Delete</a>
                </td>
              </tr>";
    }

    echo "</table><br>";
}
?>

</div>

  <!-- here link of back to dashboard-->
    <a href="dashboard.php"
     style="height:25px; 
        width:60px;
        border-radius:5px;
        background:blue;
        text-decoration:none;"
    >Bacrk</a>

<a href="logout.php" class="logout">Logout</a>

</body>
</html>
