<?php
include "db.php";

/* INSERT NEW CREDIT */
if(isset($_POST['save'])){
    $credit_text = $_POST['credit_text'];
    $sql = "INSERT INTO credits (credit_text) VALUES ('$credit_text')";
    mysqli_query($conn, $sql);
    header("Location: credit.php");
    exit();
}

/* DELETE CREDIT */
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM credits WHERE id=$id");
    header("Location: credit.php");
    exit();
}

/* UPDATE STATUS */
if(isset($_GET['status']) && isset($_GET['id'])){
    $id = $_GET['id'];
    $status = $_GET['status'];
    mysqli_query($conn, "UPDATE credits SET status='$status' WHERE id=$id");
    header("Location: credit.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Credit / Imyenda</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{font-family:Arial; background:#f2f2f2; display:flex; justify-content:center;}
        .container{background:white; width:60%; margin-top:20px; padding:20px; border-radius:10px;}
        textarea{width:100%; height:80px; padding:10px;}
        button{padding:8px 15px; border:none; background:black; color:white; border-radius:5px; cursor:pointer;}
        .item{display:flex; justify-content:space-between; background:#eee; padding:10px; margin-top:10px; border-radius:5px; align-items:center;}
        .item p.paid{text-decoration:line-through; color:green;}
        /* MEDIA QUERY */
        @media(max-width:600px){.container{width:95%;}.item{flex-direction:column; gap:5px;}}
    </style>
</head>
<body>

<div class="container">
    <h2>Credit / Imyenda</h2>

    <!-- FORM -->
    <form method="POST">
        <textarea name="credit_text" placeholder="Andika imyenda hano..." required></textarea><br><br>
        <button name="save">Save Credit</button>
    </form>

    <hr>

    <!-- DISPLAY CREDITS -->
    <?php


    
session_start();

if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}




    $result = mysqli_query($conn, "SELECT * FROM credits ORDER BY id DESC");
    while($row = mysqli_fetch_assoc($result)){
        $checked = $row['status']=='paid' ? 'checked' : '';
        $class = $row['status']=='paid' ? 'paid' : '';
    ?>
    <div class="item">
        <div>
            <form method="GET" style="display:inline;">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <input type="hidden" name="status" value="<?php echo $row['status']=='paid'?'not_paid':'paid'; ?>">
                <input type="checkbox" onchange="this.form.submit()" <?php echo $checked; ?>>
            </form>
            <p class="<?php echo $class; ?>"><?php echo $row['credit_text']; ?></p>
            <small><?php echo $row['created_at']; ?></small>
        </div>
        <a href="credit.php?delete=<?php echo $row['id']; ?>"><button style="background:red;">Delete</button></a>
    </div>
    <?php } ?>

        <!-- here link of back to dashboard-->
        <a href="dashboard.php"
         style="height:25px; 
        width:60px;
        border-radius:5px;
        background:blue;
        text-decoration:none;"
        >Back</a>
</div>

</body>
</html>
