<?php
include "db.php";
session_start();

// Protect page (login only)
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}

// DELETE saving
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM saving WHERE id=$id");
}

// SAVE saving
if(isset($_POST['save'])){
    $description = $_POST['description'];
    $amount = $_POST['amount'];
    $date = date("Y-m-d");

    mysqli_query($conn, "INSERT INTO saving(description, amount, save_date)
                         VALUES('$description','$amount','$date')");
}

// Get grouped totals per day
$totalPerDay = mysqli_query($conn, 
    "SELECT save_date, SUM(amount) as total 
     FROM saving GROUP BY save_date ORDER BY save_date DESC"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Saving Page</title>
    <link rel="stylesheet" href="saving.css">
</head>
<body>

<div class="container">
    <h2>Saving / Kuzigama Amafaranga</h2>

    <form method="post">
        <textarea name="description" placeholder="Andika icyo wazigamyeho..." required></textarea>
        <input type="number" name="amount" placeholder="Amafaranga azigamwe" required>
        <button type="submit" name="save">Save</button>
    </form>

<?php
while($dayRow = mysqli_fetch_assoc($totalPerDay)){
    $date = $dayRow['save_date'];
    $total = $dayRow['total'];

    echo "<h3>Tariki $date wazigamye: $total Frw</h3>";

    $items = mysqli_query($conn, "SELECT * FROM saving WHERE save_date='$date'");
    echo "<table>";
    echo "<tr><th>Details</th><th>Amafaranga</th><th>Action</th></tr>";

    while($row = mysqli_fetch_assoc($items)){
        echo "<tr>
                <td>{$row['description']}</td>
                <td>{$row['amount']} Frw</td>
                <td>
                  <a href='saving.php?delete={$row['id']}' onclick='return confirm(\"Delete this saving?\")'>Delete</a>
                </td>
              </tr>";
    }

    echo "</table><br>";
}
?>

</div>

<!-- here link of back to dashboard-->
    <a href="dashboard.php"
     style="height:25px; 
        width:60px;
        border-radius:5px;
        background:blue;
        text-decoration:none;"
    >Bacrk</a>

<a href="logout.php" class="logout">Logout</a>

</body>
</html>
