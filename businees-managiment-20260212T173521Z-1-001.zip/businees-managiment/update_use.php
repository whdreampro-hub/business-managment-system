<?php
include "db.php";

if(isset($_POST['email']) && isset($_POST['username']) && isset($_POST['password'])){

    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $password = password_hash($password, PASSWORD_DEFAULT);

    // since user is only one, we update id = 1
    $sql = "UPDATE users SET 
            email='$email', 
            username='$username', 
            password='$password' 
            WHERE id = 1";

    if(mysqli_query($conn, $sql)){
        echo "Credentials zahindutse neza!";
        header("location: dashboard.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }

}else{
    echo "All fields required!";
}
?>
